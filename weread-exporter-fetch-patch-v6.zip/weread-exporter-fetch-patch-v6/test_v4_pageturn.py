"""v4 自测：翻页死循环 + 无限重试。

背景（用户 2026-11-15 03:19）：
Chrome 页面本身没毛病，转换时窗口跳出来、又自动关掉、无限循环、
什么都没导出来。机制是：
- _check_next_page() 里只要按钮一直是“下一页”就永远点下去；
  外层 export.py 的 wait_for 在 timeout+60 秒后取消它，
  __main__ 再关掉 Chrome 重开 —— 于是窗口一跳出来就关掉。
- 另外两个可能导致页翻不过去的原因：
  1) pyppeteer 的 page.click() 要算坐标，启动时 viewport 是 0x0，
     点的位置可能根本没落在按钮上；
  2) innerText 可能带空白/换行，== 比较直接掉进 NotImplementedError。
- __main__ 里原来是 while True 无限重试。

v4 改了：
1. 翻页改成 JS 的 .click()，不依赖坐标；innerText 先 strip 再比；
2. 单章最多翻 MAX_PAGE_TURNS_PER_CHAPTER（默认 200）页，超了就
   停下来保存已有内容；
3. __main__ 最多重试 MAX_EXPORT_ROUNDS（默认 3）轮，还不行就
   报错退出。

测法（不需要真 Chrome / 不需要登录）：
1. 按钮一直卡在“下一页”：JS 点击 5 次（测试里把上限临时改成 5）
   后停下返回，不再死转；且 pyppeteer 的 page.click 一次都没调；
2. 按钮文字是“下一页\\n”（带换行）：strip 后照样认出来，点一次，
   再遇到“下一章”就停；
3. 按钮一开始就是“下一章”：一次都不点，直接停；
4. 静态检查：__main__.py 里没有 while True，有 3 轮上限，超了
   return -1；webpage.py 里的默认上限是 200。

跑法：python test_v4_pageturn.py
"""
import asyncio
import importlib.util
import os
import sys
import types

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.join(HERE, "weread_exporter")

# ---- stub pyppeteer ----
_pyppeteer = types.ModuleType("pyppeteer")
_pyppeteer_page = types.ModuleType("pyppeteer.page")
_pyppeteer_page.Page = object
_pyppeteer_browser = types.ModuleType("pyppeteer.browser")
_pyppeteer_browser.Browser = object
_pyppeteer_errors = types.ModuleType("pyppeteer.errors")


class _TimeoutError(Exception):
    pass


class _NetworkError(Exception):
    pass


class _ElementHandleError(Exception):
    pass


_pyppeteer_errors.TimeoutError = _TimeoutError
_pyppeteer_errors.NetworkError = _NetworkError
_pyppeteer_errors.ElementHandleError = _ElementHandleError
_pyppeteer.page = _pyppeteer_page
_pyppeteer.browser = _pyppeteer_browser
_pyppeteer.errors = _pyppeteer_errors
sys.modules["pyppeteer"] = _pyppeteer
sys.modules["pyppeteer.page"] = _pyppeteer_page
sys.modules["pyppeteer.browser"] = _pyppeteer_browser
sys.modules["pyppeteer.errors"] = _pyppeteer_errors

# ---- stub aiohttp ----
_aiohttp = types.ModuleType("aiohttp")


class _ClientTimeout:
    def __init__(self, total=None):
        self.total = total


class _ClientSession:
    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False


_aiohttp.ClientTimeout = _ClientTimeout
_aiohttp.ClientSession = _ClientSession
sys.modules["aiohttp"] = _aiohttp

# ---- stub weread_exporter.utils ----
fake_utils = types.ModuleType("weread_exporter.utils")


class _ChromeNotInstalledError(Exception):
    pass


class _BreakExportingError(Exception):
    pass


class _InvalidUserError(Exception):
    pass


class _LoadChapterFailedError(Exception):
    pass


class _LoginRequiredError(Exception):
    pass


async def _fake_fetch(url, method="GET", headers=None, data=None,
                      respond_with_headers=False):
    return b"<html></html>"


fake_utils.fetch = _fake_fetch
fake_utils.ChromeNotInstalledError = _ChromeNotInstalledError
fake_utils.BreakExportingError = _BreakExportingError
fake_utils.InvalidUserError = _InvalidUserError
fake_utils.LoadChapterFailedError = _LoadChapterFailedError
fake_utils.LoginRequiredError = _LoginRequiredError
sys.modules["weread_exporter.utils"] = fake_utils

# ---- 把 weread_exporter 当作包加载 ----
pkg = types.ModuleType("weread_exporter")
pkg.__path__ = [PKG_DIR]
sys.modules["weread_exporter"] = pkg


def _load(name, filename):
    spec = importlib.util.spec_from_file_location(
        "weread_exporter." + name, os.path.join(PKG_DIR, filename)
    )
    mod = importlib.util.module_from_spec(spec)
    sys.modules["weread_exporter." + name] = mod
    spec.loader.exec_module(mod)
    return mod


webproxy = _load("webproxy", "webproxy.py")
webpage = _load("webpage", "webpage.py")


class FakePage:
    """假页面：按给定的按钮文字序列回答 innerText。"""

    def __init__(self, button_texts):
        self.button_texts = list(button_texts)
        self.js_clicks = 0
        self.pyppeteer_clicks = 0
        self._idx = 0

    async def waitForSelector(self, selector, timeout=None):
        return object()

    async def evaluate(self, script, *args):
        if "innerText" in script:
            if self._idx < len(self.button_texts):
                text = self.button_texts[self._idx]
                self._idx += 1
            else:
                text = self.button_texts[-1]
            return text
        if ".click()" in script:
            self.js_clicks += 1
            return None
        return None

    async def click(self, selector):
        self.pyppeteer_clicks += 1
        return None


def _make_obj(button_texts):
    obj = webpage.WeReadWebPage.__new__(webpage.WeReadWebPage)
    obj._proxy_installed = True  # 让 pre_load_page 直接返回，不碰真拦截
    obj._hook_script_name = "1.abcdef01.js"
    obj._book_id = "771324e0813abbe5bg0187f1"
    obj._page = FakePage(button_texts)
    return obj


async def main():
    # 默认上限是 200
    assert webpage.MAX_PAGE_TURNS_PER_CHAPTER == 200, (
        webpage.MAX_PAGE_TURNS_PER_CHAPTER
    )
    print("0. 默认单章翻页上限 200 OK")

    # 1. 按钮一直卡在“下一页”：上限 5 次后停下，不死转；没调过 page.click
    old_cap = webpage.MAX_PAGE_TURNS_PER_CHAPTER
    webpage.MAX_PAGE_TURNS_PER_CHAPTER = 5
    try:
        obj = _make_obj(["下一页"] * 100)
        await asyncio.wait_for(obj._check_next_page(), timeout=30)
    finally:
        webpage.MAX_PAGE_TURNS_PER_CHAPTER = old_cap
    assert obj._page.js_clicks == 5, obj._page.js_clicks
    assert obj._page.pyppeteer_clicks == 0, obj._page.pyppeteer_clicks
    print("1. 按钮卡在下一页：JS 点 5 次后停下，不死转；没用 pyppeteer 点击 OK")

    # 2. 按钮文字带换行：strip 后认出来，点 1 次后遇到下一章停下
    obj = _make_obj(["下一页\n", "下一章"])
    await asyncio.wait_for(obj._check_next_page(), timeout=30)
    assert obj._page.js_clicks == 1, obj._page.js_clicks
    assert obj._page.pyppeteer_clicks == 0
    print("2. 按钮文字带换行也能识别，点 1 次后遇下一章停下 OK")

    # 3. 一开始就是下一章：一次都不点
    obj = _make_obj(["下一章"])
    await asyncio.wait_for(obj._check_next_page(), timeout=30)
    assert obj._page.js_clicks == 0, obj._page.js_clicks
    print("3. 一开始就是下一章：一次都不点 OK")

    # 4. 静态检查 __main__：重试循环不再是 while True（注释里提到
    # while True 不算，只看代码行），有 3 轮上限，超了退出
    with open(os.path.join(PKG_DIR, "__main__.py"), encoding="utf-8") as fp:
        src = fp.read()
    code_lines = [
        line for line in src.splitlines() if not line.strip().startswith("#")
    ]
    code = "\n".join(code_lines)
    assert "while True:" not in code, "还有 while True 无限重试"
    assert "MAX_EXPORT_ROUNDS = 3" in src
    assert "for _round in range(1, MAX_EXPORT_ROUNDS + 1)" in src
    assert "stop retrying" in src
    print("4. __main__ 无 while True，3 轮上限、超了退出 OK")

    print("\nALL V4 TESTS PASSED")


if __name__ == "__main__":
    asyncio.run(main())
