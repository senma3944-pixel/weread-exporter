"""Mock 自测：Fetch.enable 版 webproxy.py，不需要真 Chrome / 不需要登录。

跑法（在 weread-exporter 的 .venv 里，或任意 Python 3.8+）：
    python test_fetch_patch.py

测的是（v2 共 8 组）：
1. setup_interception 调 Fetch.enable，不调 Network.setRequestInterception；
   v2 用 per-rule patterns，不用 "*"
2. Document 请求：Python 侧 aiohttp 拉回 HTML -> 注入 hook 脚本 -> Fetch.fulfillRequest，
   且去掉 content-length，body base64 解出来含注入的 script 标签；
   v2 确认走 aiohttp 直接调用（带 ClientTimeout），不是 utils.fetch
3. hook.js 请求：Mock 回包
4. hera/logkv：Mock 204；chapter：Continue；无规则请求：Continue
5. 同 URL 的 Script 请求不匹配 Document 规则（resourceType 过滤）
6. data: 请求直接放行；重复放行只发一次 CDP
7. v2：Document re-fetch 挂起 -> 超时后 Continue，任务结束
8. v2：卡住的 CDP send -> _send_once 超时返回 False，不挂起
"""
import asyncio
import base64
import importlib.util
import os
import sys
import types

HERE = os.path.dirname(os.path.abspath(__file__))
WEBPROXY = os.path.join(HERE, "weread_exporter", "webproxy.py")

# ---- stub pyppeteer / utils，让 webproxy.py 能独立加载 ----
_pyppeteer = types.ModuleType("pyppeteer")
_pyppeteer_page = types.ModuleType("pyppeteer.page")
_pyppeteer_page.Page = object
_pyppeteer.page = _pyppeteer_page
sys.modules["pyppeteer"] = _pyppeteer
sys.modules["pyppeteer.page"] = _pyppeteer_page

fake_utils = types.ModuleType("weread_exporter.utils")


async def fake_fetch(url, method="GET", headers=None, respond_with_headers=False):
    body = b"<html><head></head><body>hi</body></html>"
    if respond_with_headers:
        return (200, {"Content-Type": "text/html", "Content-Length": "999"}, body)
    return body


fake_utils.fetch = fake_fetch
FAKE_FETCH_CALLS = []
_orig_fake_fetch = fake_fetch


async def _recording_fake_fetch(*a, **kw):
    FAKE_FETCH_CALLS.append(a)
    return await _orig_fake_fetch(*a, **kw)


fake_utils.fetch = _recording_fake_fetch

# ---- stub aiohttp: get_http_response v2 uses aiohttp directly with
# ClientTimeout (utils.fetch swallows CancelledError, so it can't be used
# for a real timeout). The fake session honours FAKE_AIOHTTP_DELAY.
FAKE_AIOHTTP_BODY = b"<html><head></head><body>hi</body></html>"
FAKE_AIOHTTP_DELAY = 0.0
AIOHTTP_SESSIONS = []


class _FakeAiohttpResponse:
    def __init__(self):
        self.status = 200
        self.headers = {"Content-Type": "text/html", "Content-Length": "999"}

    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False

    async def read(self):
        if FAKE_AIOHTTP_DELAY:
            await asyncio.sleep(FAKE_AIOHTTP_DELAY)
        return FAKE_AIOHTTP_BODY


class _FakeAiohttpSession:
    def __init__(self, timeout=None):
        self.timeout = timeout
        AIOHTTP_SESSIONS.append(self)

    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False

    def get(self, url, headers=None, data=None):
        return _FakeAiohttpResponse()

    def post(self, url, headers=None, data=None):
        return _FakeAiohttpResponse()


class _FakeClientTimeout:
    def __init__(self, total=None, **kw):
        self.total = total


_fake_aiohttp = types.ModuleType("aiohttp")
_fake_aiohttp.ClientSession = _FakeAiohttpSession
_fake_aiohttp.ClientTimeout = _FakeClientTimeout
sys.modules["aiohttp"] = _fake_aiohttp

pkg = types.ModuleType("weread_exporter")
pkg.__path__ = [os.path.join(HERE, "weread_exporter")]
sys.modules["weread_exporter"] = pkg
sys.modules["weread_exporter.utils"] = fake_utils

spec = importlib.util.spec_from_file_location("weread_exporter.webproxy", WEBPROXY)
webproxy = importlib.util.module_from_spec(spec)
sys.modules["weread_exporter.webproxy"] = webproxy
spec.loader.exec_module(webproxy)


class FakeClient:
    def __init__(self):
        self.sends = []  # (method, params)
        self.listeners = {}

    async def send(self, method, params=None):
        self.sends.append((method, params or {}))
        return {}

    def on(self, event, listener):
        self.listeners[event] = listener


class FakeNetworkManager:
    def __init__(self):
        self._userRequestInterceptionEnabled = False
        self._protocolRequestInterceptionEnabled = False


class FakePage:
    def __init__(self, client):
        self._client = client
        self._networkManager = FakeNetworkManager()


def event(request_id, url, method="GET", resource_type="Document", headers=None):
    return {
        "requestId": request_id,
        "request": {
            "url": url,
            "method": method,
            "headers": headers or {"cookie": "wr_vid=123"},
            "postData": None,
        },
        "resourceType": resource_type,
    }


def find_send(client, method, request_id=None):
    out = []
    for m, p in client.sends:
        if m != method:
            continue
        if request_id is not None and p.get("requestId") != request_id:
            continue
        out.append(p)
    return out


async def main():
    client = FakeClient()
    page = FakePage(client)

    # 回调：照抄 webpage.py 里的行为（简化版）
    def on_document_request(req):
        req.headers["cookie"] = req.headers.get("cookie", "") + "; wr_useHorizonReader=0"
        return {"type": webproxy.EnumProxyType.Continue, "headers": req.headers}

    def on_document_response(resp):
        content = resp.content.replace(
            "</head>", "<script src='https://cdn.weread.qq.com/web/1.abcdef12.js'></script>\n</head>"
        )
        return {"status": resp.status, "headers": resp.headers, "body": content.encode()}

    def on_hook(req):
        return {
            "type": webproxy.EnumProxyType.Mock,
            "status": 200,
            "headers": {"Content-Type": "application/json"},
            "body": b"/* hook.js */",
        }

    def on_log(req):
        return {"type": webproxy.EnumProxyType.Mock, "status": 204, "headers": {}}

    def on_chapter(req):
        return {"type": webproxy.EnumProxyType.Continue}

    rules = [
        webproxy.ProxyRule("*/hera/*", on_log),
        webproxy.ProxyRule("*/web/book/chapter/*", on_chapter),
        webproxy.ProxyRule("*/web/reader/*", on_document_request, resource_type="Document"),
        webproxy.ProxyRule("*/web/reader/*", on_document_response, resource_type="Document", stage=webproxy.EnumProxyStage.Response),
        webproxy.ProxyRule("*/web/1.abcdef12.js", on_hook, resource_type="Script"),
    ]
    proxy = webproxy.WebProxy(page, rules)
    await proxy.setup_interception()

    methods = [m for m, _ in client.sends]
    assert "Fetch.enable" in methods, methods
    assert "Network.setRequestInterception" not in methods, methods
    assert "Network.setCacheDisabled" in methods, methods
    assert "Fetch.requestPaused" in client.listeners, client.listeners.keys()
    # v2: per-rule patterns, not "*"
    enable = [p for m, p in client.sends if m == "Fetch.enable"][0]
    patterns = enable["patterns"]
    assert all(p.get("urlPattern") != "*" for p in patterns), patterns
    assert any(p.get("resourceType") == "Document" and "web/reader" in p.get("urlPattern", "")
               for p in patterns), patterns
    assert any("1.abcdef12.js" in p.get("urlPattern", "") for p in patterns), patterns
    assert all(p.get("requestStage") == "Request" for p in patterns), patterns
    print("1. setup_interception: Fetch.enable OK, no Network.setRequestInterception, per-rule patterns")

    # 2. Document
    await proxy.handle_fetch_paused(
        event("r1", "https://weread.qq.com/web/reader/771324e0813abbe5bg0187f1kc123", resource_type="Document")
    )
    fulfills = find_send(client, "Fetch.fulfillRequest", "r1")
    assert len(fulfills) == 1, fulfills
    body = base64.b64decode(fulfills[0]["body"]).decode()
    assert "1.abcdef12.js" in body, body
    header_names = [h["name"].lower() for h in fulfills[0]["responseHeaders"]]
    assert "content-length" not in header_names, header_names
    # v2: Document re-fetch must go through aiohttp directly (with a real
    # ClientTimeout), NOT utils.fetch (which swallows CancelledError).
    assert AIOHTTP_SESSIONS, "get_http_response did not use aiohttp"
    assert AIOHTTP_SESSIONS[-1].timeout.total == webproxy.FETCH_RESPONSE_TIMEOUT
    assert FAKE_FETCH_CALLS == [], FAKE_FETCH_CALLS
    print("2. Document: fulfill with injected hook script, content-length stripped OK, via aiohttp+ClientTimeout")

    # 3. hook.js
    await proxy.handle_fetch_paused(
        event("r2", "https://cdn.weread.qq.com/web/1.abcdef12.js", resource_type="Script")
    )
    fulfills = find_send(client, "Fetch.fulfillRequest", "r2")
    assert len(fulfills) == 1
    assert base64.b64decode(fulfills[0]["body"]) == b"/* hook.js */"
    print("3. hook.js: Mock fulfill OK")

    # 4. hera mock 204, chapter continue, no-rule continue
    await proxy.handle_fetch_paused(event("r3", "https://weread.qq.com/hera/logkv", method="POST"))
    assert find_send(client, "Fetch.fulfillRequest", "r3")[0]["responseCode"] == 204
    await proxy.handle_fetch_paused(event("r4", "https://weread.qq.com/web/book/chapter/123"))
    assert find_send(client, "Fetch.continueRequest", "r4")
    await proxy.handle_fetch_paused(event("r5", "https://example.com/img.png", resource_type="Image"))
    assert find_send(client, "Fetch.continueRequest", "r5")
    print("4. hera Mock 204 / chapter Continue / no-rule Continue OK")

    # 5. 同 URL 的 Script 请求不应匹配 Document 规则
    await proxy.handle_fetch_paused(
        event("r6", "https://weread.qq.com/web/reader/771324e0813abbe5bg0187f1kc123", resource_type="Script")
    )
    assert find_send(client, "Fetch.continueRequest", "r6"), client.sends
    assert not find_send(client, "Fetch.fulfillRequest", "r6")
    print("5. resourceType filter: Script request to /web/reader/* is NOT treated as Document OK")

    # 6. data: 直接放行；重复调用只发一次
    await proxy.handle_fetch_paused(
        {"requestId": "r7", "request": {"url": "data:text/plain,hi", "method": "GET", "headers": {}}, "resourceType": "Other"}
    )
    assert find_send(client, "Fetch.continueRequest", "r7")
    # 对 r5 再调一次 handle_fetch_paused 会新建 adapter，CDP 层面会再发一次——
    # 这里测的是同一个 _FetchRequest 对象重复 respond/continue 只发一次
    fake = webproxy._FetchRequest(proxy, event("r8", "https://example.com/x.png", resource_type="Image"))
    await fake.continue_()
    await fake.continue_()
    await fake.respond({"status": 200, "body": b"x"})
    assert len(find_send(client, "Fetch.continueRequest", "r8")) == 1
    print("6. data: passthrough + _FetchRequest send-once OK")

    # 7. v2: Document re-fetch hangs -> timeout -> Continue, task finishes.
    # The hang is simulated in the fake aiohttp session (real utils.fetch
    # swallows CancelledError, so the timeout must work through the
    # aiohttp path, not through utils.fetch).
    global FAKE_AIOHTTP_DELAY
    FAKE_AIOHTTP_DELAY = 3600.0
    webproxy.FETCH_RESPONSE_TIMEOUT = 0.3
    webproxy.HANDLE_TIMEOUT = 2.0
    t0 = asyncio.get_running_loop().time()
    await proxy.handle_fetch_paused(
        event("r9", "https://weread.qq.com/web/reader/771324e0813abbe5bg0187f1kc123", resource_type="Document")
    )
    dur = asyncio.get_running_loop().time() - t0
    assert dur < 5, dur
    assert find_send(client, "Fetch.continueRequest", "r9"), client.sends
    assert not find_send(client, "Fetch.fulfillRequest", "r9")
    print(f"7. slow Document re-fetch: timed out in {dur:.2f}s, fell back to Continue, task finished OK")

    # 8. v2: stuck CDP send -> _send_once times out instead of hanging forever
    class HangingClient(FakeClient):
        async def send(self, method, params=None):
            if method.startswith("Fetch."):
                await asyncio.sleep(3600)
            return await super().send(method, params)

    webproxy.CDP_SEND_TIMEOUT = 0.2
    hanging_proxy = webproxy.WebProxy(FakePage(HangingClient()), rules)
    fake_req = webproxy._FetchRequest(
        hanging_proxy, event("r10", "https://example.com/x.png", resource_type="Image")
    )
    t0 = asyncio.get_running_loop().time()
    ok = await fake_req._send_once("Fetch.continueRequest", {"requestId": "r10"})
    dur = asyncio.get_running_loop().time() - t0
    assert ok is False and dur < 5, (ok, dur)
    # continue_() wraps _send_once and returns None; it must also return fast
    t0 = asyncio.get_running_loop().time()
    await fake_req.continue_()
    assert asyncio.get_running_loop().time() - t0 < 5
    print(f"8. stuck CDP send: _send_once returned False after {dur:.2f}s instead of hanging OK")

    print("\nALL MOCK TESTS PASSED")


if __name__ == "__main__":
    asyncio.run(main())
