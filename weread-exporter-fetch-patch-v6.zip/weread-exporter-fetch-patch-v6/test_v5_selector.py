"""v5 自测：翻页按钮选择器。

背景（用户 2026-11-15 04:04，从真机 live DOM 里抠出来的 HTML）：
    <button class="renderTarget_pager_button">...上一页...</button>
    <button class="renderTarget_pager_button renderTarget_pager_button_right">
        ...下一页...</button>
旧的 `button.readerFooter_button` 在新版阅读器里已经不存在，
程序等 60 秒也等不到，直接超时，第 2 章永远过不去。
v5 把三处都换成 `renderTarget_pager_button_right`（右边的按钮，
即下一页/下一章；左边不带 _right 的是上一页）：
1. wait_for_selector 等按钮出现；
2. 读按钮 innerText 判断下一页/下一章；
3. JS .click() 点按钮翻页。

测法（不需要真 Chrome / 不需要登录）：
1. 假页面里旧选择器永远超时（和真机一样）、新选择器能找到：
   按钮文字依次是“下一页、下一页、下一章”，应 JS 点 2 次后停下；
   且三处用的全是新选择器，旧选择器一次都没出现过；
2. 静态检查：webpage.py 的代码行（不算注释）里没有
   readerFooter_button，新选择器出现 3 次。

跑法：python test_v5_selector.py
"""
import asyncio
import importlib.util
import os
import sys
import types

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.join(HERE, "weread_exporter")

# ---- stub pyppeteer ----
_pyppeteer = types.ModuleType("pyppeteer")
_pyppeteer_page = types.ModuleType("pyppeteer.page")
_pyppeteer_page.Page = object
_pyppeteer_browser = types.ModuleType("pyppeteer.browser")
_pyppeteer_browser.Browser = object
_pyppeteer_errors = types.ModuleType("pyppeteer.errors")


class _TimeoutError(Exception):
    pass


class _NetworkError(Exception):
    pass


class _ElementHandleError(Exception):
    pass


_pyppeteer_errors.TimeoutError = _TimeoutError
_pyppeteer_errors.NetworkError = _NetworkError
_pyppeteer_errors.ElementHandleError = _ElementHandleError
_pyppeteer.page = _pyppeteer_page
_pyppeteer.browser = _pyppeteer_browser
_pyppeteer.errors = _pyppeteer_errors
sys.modules["pyppeteer"] = _pyppeteer
sys.modules["pyppeteer.page"] = _pyppeteer_page
sys.modules["pyppeteer.browser"] = _pyppeteer_browser
sys.modules["pyppeteer.errors"] = _pyppeteer_errors

# ---- stub aiohttp ----
_aiohttp = types.ModuleType("aiohttp")


class _ClientTimeout:
    def __init__(self, total=None):
        self.total = total


class _ClientSession:
    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False


_aiohttp.ClientTimeout = _ClientTimeout
_aiohttp.ClientSession = _ClientSession
sys.modules["aiohttp"] = _aiohttp

# ---- stub weread_exporter.utils ----
fake_utils = types.ModuleType("weread_exporter.utils")


class _ChromeNotInstalledError(Exception):
    pass


class _BreakExportingError(Exception):
    pass


class _InvalidUserError(Exception):
    pass


class _LoadChapterFailedError(Exception):
    pass


class _LoginRequiredError(Exception):
    pass


async def _fake_fetch(url, method="GET", headers=None, data=None,
                      respond_with_headers=False):
    return b"<html></html>"


fake_utils.fetch = _fake_fetch
fake_utils.ChromeNotInstalledError = _ChromeNotInstalledError
fake_utils.BreakExportingError = _BreakExportingError
fake_utils.InvalidUserError = _InvalidUserError
fake_utils.LoadChapterFailedError = _LoadChapterFailedError
fake_utils.LoginRequiredError = _LoginRequiredError
sys.modules["weread_exporter.utils"] = fake_utils

# ---- 把 weread_exporter 当作包加载 ----
pkg = types.ModuleType("weread_exporter")
pkg.__path__ = [PKG_DIR]
sys.modules["weread_exporter"] = pkg


def _load(name, filename):
    spec = importlib.util.spec_from_file_location(
        "weread_exporter." + name, os.path.join(PKG_DIR, filename)
    )
    mod = importlib.util.module_from_spec(spec)
    sys.modules["weread_exporter." + name] = mod
    spec.loader.exec_module(mod)
    return mod


webproxy = _load("webproxy", "webproxy.py")
webpage = _load("webpage", "webpage.py")

NEW = "renderTarget_pager_button_right"
OLD = "readerFooter_button"


class FakePage:
    """假页面：旧选择器永远超时（和真机新版阅读器一样）。"""

    def __init__(self, button_texts):
        self.button_texts = list(button_texts)
        self.selectors_seen = []
        self.js_clicks = 0
        self.pyppeteer_clicks = 0
        self._idx = 0

    async def waitForSelector(self, selector, timeout=None):
        self.selectors_seen.append(selector)
        if OLD in selector:
            # 真机上旧选择器什么都找不到，等 60 秒超时
            raise _TimeoutError("no such element: " + selector)
        return object()

    async def evaluate(self, script, *args):
        if "innerText" in script:
            assert NEW in script, script
            assert OLD not in script, script
            if self._idx < len(self.button_texts):
                text = self.button_texts[self._idx]
                self._idx += 1
            else:
                text = self.button_texts[-1]
            return text
        if ".click()" in script:
            assert NEW in script, script
            assert OLD not in script, script
            self.js_clicks += 1
            return None
        return None

    async def click(self, selector):
        self.pyppeteer_clicks += 1
        return None


async def main():
    obj = webpage.WeReadWebPage.__new__(webpage.WeReadWebPage)
    obj._proxy_installed = True  # 让 pre_load_page 直接返回，不碰真拦截
    obj._hook_script_name = "1.abcdef01.js"
    obj._book_id = "771324e0813abbe5bg0187f1"
    obj._page = FakePage(["下一页", "下一页", "下一章"])

    # 1. 三页翻完停下：等按钮、读文字、点按钮全是新选择器
    await asyncio.wait_for(obj._check_next_page(), timeout=30)
    assert obj._page.js_clicks == 2, obj._page.js_clicks
    assert obj._page.pyppeteer_clicks == 0
    assert obj._page.selectors_seen, "一次都没等过按钮"
    assert all(NEW in s for s in obj._page.selectors_seen), (
        obj._page.selectors_seen
    )
    assert all(OLD not in s for s in obj._page.selectors_seen), (
        obj._page.selectors_seen
    )
    print("1. 新选择器找到按钮，JS 点 2 次后遇下一章停下；旧选择器没出现过 OK")

    # 2. 静态检查：代码行里没有旧名字，新名字出现 3 次（等、读、点）
    with open(os.path.join(PKG_DIR, "webpage.py"), encoding="utf-8") as fp:
        lines = fp.read().splitlines()
    code = "\n".join(
        line for line in lines if not line.strip().startswith("#")
    )
    assert OLD not in code, "代码里还有 readerFooter_button"
    assert code.count(NEW) == 3, code.count(NEW)
    print("2. 代码行无旧选择器，新选择器出现 3 次 OK")

    print("\nALL V5 TESTS PASSED")


if __name__ == "__main__":
    asyncio.run(main())
