# weread-exporter Fetch.enable 补丁

## 针对的问题
- 环境：Windows，Python 3.14，Chrome 157.0.8103.51，书号 771324e0813abbe5bg0187f1
- 原始报错（2026-11-15 00:42，第 2 章“版权信息”）：
  - `pyppeteer.errors.NetworkError: Protocol error (Network.setRequestInterception): 'Network.setRequestInterception' wasn't found`
  - 随后 `pyppeteer.errors.ElementHandleError: Evaluation failed: ReferenceError: canvasContextHandler is not defined`
- 根因：`weread_exporter/webproxy.py` 的 `WebProxy.setup_interception()` 直接调 CDP 的
  `Network.setRequestInterception`。Chrome 156 起删除了这个方法（Puppeteer 3.27 changelog：
  Regenerating the protocol against Chrome 156 drops … the protocol-level
  `setRequestInterception`），改走 Fetch 域。Python 的 pyppeteer 2.0.0 内部
  `NetworkManager.setRequestInterception()` 同样调这个已删除的方法，所以
  高层 `page.setRequestInterception(True)` 也一样会失败。
- 登录不是问题：日志里 00:42:38 已拿到 skey/vid，扫码登录成功。失败在拦截/注入 hook.js 那一步。

## 改了什么（只改 `weread_exporter/webproxy.py`，其他文件不动）
1. `setup_interception()`：不再调 `Network.setRequestInterception`，改调
   `Fetch.enable`（pattern `{"urlPattern": "*", "requestStage": "Request"}`），
   监听 `Fetch.requestPaused`。`Network.setCacheDisabled` 保留（Chrome 156+ 还有这个方法），
   失败也不中断安装。
2. 不再碰 pyppeteer 的 NetworkManager 拦截开关（两个都保持 False），否则它内部
   会再去调已删除的方法。
3. 新增 `_FetchRequest` 适配器：把 `Fetch.requestPaused` 事件包成原来
   `handle_request()` 认识的 Request 对象（url / method / headers / postData /
   resourceType / `_interceptionHandled`，以及 `continue_()` / `respond()` / `abort()`），
   分别用 `Fetch.continueRequest` / `Fetch.fulfillRequest` / `Fetch.failRequest` 实现。
   规则回调（`on_document_request` / `on_document_response` / `on_hook_script_request` /
   `on_log_request` / `on_sentry_request` / `on_single_report_request` / `on_chapter_request`）
   完全不用改。
4. `ProxyRule.matches()` 增加 resourceType 过滤：Fetch 只用 `*` 通配，
   原来由 CDP pattern 做的 resourceType 分流现在在 Python 里补上，
   Document 规则不会误伤同 URL 的 Script/XHR 请求。
5. `respond()` 里去掉 `content-length` / `content-encoding` / `transfer-encoding` 等头，
   因为 body 被改过（注入 hook 脚本），旧长度会把页面截断；不给 content-length 时
   Chrome 会自己算。body 按 str/bytes 处理后 base64 编码传给 `Fetch.fulfillRequest`。
6. 兜底：`handle_fetch_paused()` 里任何异常都会尝试 `continue_()`，绝不让请求
   一直暂停导致页面卡死；每个 requestId 只放行/回包/中断一次。
7. 保留 `get_interception_pattern()` 作兼容，新增 `get_fetch_pattern()` /
   `get_fetch_patterns()`。

## 测了什么（本地，2026-11-15）
- `python -m py_compile webproxy.py`：通过
- `python test_fetch_patch.py`（Mock 自测，不需要真 Chrome / 不需要登录）：v1 是 6 组，v2 是 8 组，全部通过
  - setup 只调 `Fetch.enable`，不调 `Network.setRequestInterception`；v2 用 per-rule patterns，不用 `"*"`
  - Document 请求：aiohttp 拉回 HTML -> 注入 hook 脚本 -> fulfill，body 解出来含注入标签，content-length 已去掉；v2 确认走的是 aiohttp 直接调用（带 ClientTimeout），不是 utils.fetch
  - hook.js Mock 回包；hera Mock 204；chapter Continue；无规则 Continue
  - 同 URL 的 Script 请求不匹配 Document 规则
  - data: 直接放行；同一 `_FetchRequest` 重复调用只发一次 CDP
  - v2 新增：Document re-fetch 挂起 -> 超时后 Continue，任务结束；卡住的 CDP send -> `_send_once` 超时返回 False，不挂起
- 真实 pyppeteer 2.0.0 + aiohttp + Pillow 环境下 `from weread_exporter.webproxy import WebProxy`：导入成功
- 真实 Chrome 157（Chrome for Testing 157.0.8103.78，linux64）+ 本地模拟服务器：`repro_chrome157.py`
  - baseline / redirect / many（30 个子资源）/ preflight（跨域 OPTIONS）/ websocket / large-doc（2MB HTML）：全部通过，hook 注入成功，footer 按钮出现，chapter POST 的 body 原样到达服务器，hera/sentry 不经过服务器，挂起任务 0 个
  - slow-doc（服务器把 Document 拖 20s）：v1 会挂起（见下）；v2 超时 5s 后 Continue，handler 5.007s 结束，页面由 Chrome 自己拉回，挂起任务 0 个（代价是这次没有注入 hook，见“已知取舍”）

## v2（2026-11-15）：修复 01:13 的挂起

### 01:13 出了什么事
补丁装上后 setup 不再崩，但第 2 章还是失败：`load selector timeout` 60s，`canvasContextHandler is not defined`，没有 epub/pdf。关机日志里有两个 `WebProxy.handle_fetch_paused()` 任务还挂在 `webproxy.py:608`（`await self.handle_request(fake)`），页面一直没渲染完，hook.js 没注入。

### 复现结论（真实 Chrome 157 + 本地服务器，`repro_chrome157.py`）
- v1 的 Fetch 机制本身在 Chrome 157 上是对的：baseline、redirect、30 个子资源、跨域 preflight、websocket、2MB 文档全部通过，Document 10ms、hook Mock、chapter POST body 原样、hera/sentry Mock，没有挂起任务。
- 唯一能复现挂起的是 slow-doc：服务器把 Document 拖 20s，`handle_fetch_paused` 就挂 20s，goto 10s 超时后任务还在挂起——和用户 01:13 关机日志里两个挂起任务一模一样。
- 根因是 Document re-fetch 那一步没有任何超时：`utils.fetch` / aiohttp 没传 timeout，而且 `utils.fetch` 用 bare `except:`，会吞掉 `asyncio.CancelledError` 并重试最多 3 次。实测：v2 第一版只加了 `asyncio.wait_for`，5s 超时确实触发了（日志 `Fetch url … failed / CancelledError`），但它立刻重试，又拖了 20s，总共 25s 才返回——`wait_for` 单独根本取消不掉它。

### v2 改了什么（只改 `weread_exporter/webproxy.py`）
1. **per-rule Fetch patterns，不再用 `"*"`**：只暂停 hera / sentry / chapter / river / reader-Document / hook 脚本这 7 条规则的请求，图片、CSS、JS、wasm、favicon 等根本不进 Python，Chrome 自己直接走。实测 Chrome 157 上 per-rule pattern（`*/hera/*`、`*/web/reader/*` + resourceType Document 等）都能正常匹配。
2. **`get_http_response` 不再走 `utils.fetch`，直接用 aiohttp + `ClientTimeout(total=20s)`**：超时由 aiohttp 内部触发，本函数不吞 `CancelledError`。aiahttp 不可用时回退到 `utils.fetch`（Mock 自测用这条路）。
3. **三层超时 + 放行兜底**（模块常量，可改）：`FETCH_RESPONSE_TIMEOUT=20s`（Document re-fetch）、`CDP_SEND_TIMEOUT=10s`（一次 Fetch.continue/fulfill/fail 的 CDP 往返，pyppeteer 的 `send()` 本身没有超时）、`HANDLE_TIMEOUT=30s`（整个 `handle_fetch_paused`）。超时后一律 `Fetch.continueRequest` 放行，绝不让请求一直暂停。

### 已知取舍（重要）
- 超时放行后，Chrome 自己拉回 Document，页面能加载、footer 按钮能出现，但**这次没有注入 hook**，所以 `canvasContextHandler` 还是 undefined，`get_markdown` 这一章还是会失败。`export.py` 会重试 `goto_chapter` 最多 3 次；如果服务器只是偶尔慢，重试可能成功；如果服务器每次都超过 20s，导出还是失败，但不会再无限挂起——你会在日志里看到明确的 `Get HTTP response timed out after 20.0s … continuing original request`，而不是关机时两个挂起任务。
- 如果想把超时改大/改小，改 `webproxy.py` 顶部的 `FETCH_RESPONSE_TIMEOUT` 等常量即可。

### 顺带发现（没改，需要你决定）
- `utils.fetch`（`weread_exporter/utils.py`）的 bare `except:` 会吞 `CancelledError` 并重试，这也是 v1 超时失效的另一半原因。v2 绕过了它（Document 不再走它），但 `get_book_info` / `get_user_info` 等其他地方还在用它。如果要根治，utils.py 里应在 bare `except:` 前加 `except asyncio.CancelledError: raise`，并给 aiohttp 加 timeout——这个文件不在本次补丁包里，改之前请确认。

## v3（2026-11-15）：修复断连重试后拦截丢失

### 02:05 出了什么事
v2 装上后重跑，第 2 章还是失败，但死法变了，是好消息和坏消息各一个：
- 好消息：v2 的超时兜底生效了。关机日志里**没有**挂起的
  `handle_fetch_paused` 任务了（01:13 那次有两个）。02:06:00 的两条
  `Fetch.fulfillRequest ... timed out after 10.0s` 是第一轮里已经
  发出去、但目标 Chrome 已死的 CDP 发送，v2 按设计 10 秒放弃，
  没有无限挂住。
- 坏消息：还是 `load selector timeout` + `canvasContextHandler is not defined`，
  没有 epub/pdf。而且第二轮（02:05:50 重启 Chrome 之后）日志里
  **完全没有** `Setup interception (Fetch.enable)` 和任何
  `Handle request`，拦截根本没跑起来。

### 根因（代码里能对上号）
`webpage.py` 的 `pre_load_page()` 开头：
```python
if self._proxy_installed:
    return
self._proxy_installed = True
```
`_proxy_installed` 只在 `__init__`（`webpage.py:70`）里设成 False，
`launch()` 和 `close()` 都不重置。而 `__main__.py` 的重试循环是：
连接断掉 → `LoadChapterFailedError` → `page.close()` → 对**同一个**
`WeReadWebPage` 对象再调 `page.launch()`（新浏览器、新页面）。
第二轮 `goto_chapter` → `pre_load_page()` 直接 return，
新会话永远收不到 `Fetch.enable`，监听还挂在已死的旧会话上。
所以第二轮零拦截 → hook 注不进去 → `canvasContextHandler` 一定
是 undefined。第一轮里拦截是正常的（02:05:50 之前有 Handle request
日志），死的是第一轮 Chrome 的 websocket 连接本身。

### v3 改了什么（新增改 `weread_exporter/webpage.py`，只加 1 行逻辑）
`launch()` 开头加 `self._proxy_installed = False`（带注释），每次
launch 都是全新浏览器，必须重新执行 `Fetch.enable`。同一会话内
`pre_load_page()` 的“只装一次”保护还在，不会重复 enable。

### v3 测了什么
- `python -m py_compile webpage.py webproxy.py`：通过
- 新增 `test_v3_relaunch.py`（Mock，不需要真 Chrome）：4 组全部通过
  ——标志为 True 时不重复安装；模拟 launch 重置后重新安装；再断连
  再重置后累计安装 2 次；静态检查重置行确实在 `launch()` 里且在
  `pyppeteer.launch` 之前。
- v2 的 `test_fetch_patch.py` 8 组重新跑过，全部通过。

### 还没解释的：第一轮的连接为什么断
02:05:50,901 和 01:12:14,664 两次，websocket 都是在跑得好好的时候
突然断掉（`connection unexpectedly closed` / WinError 10053），v1
和 v2 下都出现过，原因还没定位，可能是 Chrome / websocket 在
Windows 下的偶发不稳定。重试循环本来就是为它准备的，v3 修好后
重试那轮应该能正常跑完。如果 v3 之后连接还是每次都在同一个地方
断，把那次的完整日志 + `webpage.html` / `screenshot.jpg` 发回来，
再往 Chrome 崩溃那个方向查。

## v4（2026-11-15）：修翻页死循环 + 无限重试

### 03:19 用户确认的现象
Chrome 页面本身没毛病，转换时窗口跳出来、又自动关掉、无限循环、
什么都没导出来。机制是两层循环套在一起：
- 内层：`webpage.py` 的 `_check_next_page()` 里只要按钮一直是
  “下一页”就永远点下去，没有任何退出条件；
- 外层：`export.py` 的 `wait_for` 在 timeout+60 秒后取消它，
  `__main__.py` 的 `while True` 再关掉 Chrome 重开。
于是窗口一跳出来就关掉，永远在第 2 章（本书第一章就是
第 2 章“版权信息”，19 章，书名《学会自学 2026版》）打转，
`cache\...\chapters` 里 0 个文件。

### v4 改了什么（新增改 `weread_exporter/__main__.py`，再改 `webpage.py`）
1. 翻页改成 JS 的 `.click()`：`pyppeteer` 的 `page.click()` 要算
   坐标，启动时 viewport 被设成 0x0，点的位置可能根本没落在按钮
   上；JS 点击不依赖坐标。
2. 按钮文字先 `strip()` 再比：`innerText` 带空白/换行时原来的
   `==` 比较会直接掉进 `NotImplementedError`，导致每轮都失败重开。
3. 单章翻页上限 `MAX_PAGE_TURNS_PER_CHAPTER = 200`（`webpage.py`
   顶部常量）：超了就停下来保存已有内容，不再死转；每 50 页打
   一条进度日志。
4. `__main__.py` 的 `while True` 改成最多 `MAX_EXPORT_ROUNDS = 3`
   轮：3 轮还不行就记 `Export failed after 3 rounds, stop retrying`
   并退出，不再无限重开 Chrome。

### v4 测了什么
- `python -m py_compile webpage.py webproxy.py __main__.py`：通过
- 新增 `test_v4_pageturn.py`（Mock，不需要真 Chrome）：5 组全部通过
  ——默认上限 200；按钮卡在“下一页”时 JS 点 5 次（测试用上限）
  后停下，没调过 `page.click`；带换行的“下一页\n”能识别；一开始
  就是“下一章”时一次都不点；`__main__.py` 代码里无 `while True`，
  有 3 轮上限、超了退出。
- v2 的 `test_fetch_patch.py` 8 组和 v3 的 `test_v3_relaunch.py`
  4 组重新跑过，全部通过。

### 注意
- 装 v4 前先把正在跑的那次停掉（CMD 里 `Ctrl+C`，或直接关掉黑
  窗口），不然跑着的还是旧代码，换文件也没用。
- v4 保证程序再也不会无限转，但如果翻页本身还是不通（比如按钮
  点了页就是不动），单章到 200 页上限后会保存已有内容继续往后
  走，个别章节可能只有部分内容；如果 3 轮都失败，程序会直接退
  出并报错，把最后 30 行日志发回来再查。

## v5（2026-11-15）：修翻页按钮选择器

### 04:03 用户发来的截图
截图里阅读器显示完全正常：左边版权信息、右边引言正文，底下
“下一页”按钮看得见，登录也没问题，字也在正常画。问题不在页面，
在程序找按钮用的名字对不上。

### 根因（用户机器上 live DOM 里抠出来的 HTML）
```html
<button class="renderTarget_pager_button">...上一页...</button>
<button class="renderTarget_pager_button renderTarget_pager_button_right">
  ...下一页...</button>
```
现在的翻页按钮叫 `renderTarget_pager_button`（左边上一页）和
`renderTarget_pager_button_right`（右边下一页/下一章），旧的
`readerFooter_button` 在新版阅读器里已经不存在。程序等
`button.readerFooter_button` 等 60 秒也等不到，直接超时，第 2 章
永远过不去，然后关掉 Chrome 重开、无限循环。

### v5 改了什么（只改 `weread_exporter/webpage.py` 的三处）
`_check_next_page()` 里等按钮、读按钮文字、JS 点按钮三处，全从
`readerFooter_button` 换成 `renderTarget_pager_button_right`
（右边的按钮，即下一页/下一章）。

### v5 测了什么
- `python -m py_compile webpage.py`：通过
- 新增 `test_v5_selector.py`（Mock，不需要真 Chrome）：2 组全部通过
  ——假页面里旧选择器永远超时（和真机一样）、新选择器能找到，
  按钮文字“下一页、下一页、下一章”时 JS 点 2 次后停下，旧选择器
  一次都没出现；静态检查代码行里没有旧名字，新名字出现 3 次。
- v2 的 `test_fetch_patch.py` 8 组、v3 的 `test_v3_relaunch.py` 4 组、
  v4 的 `test_v4_pageturn.py` 5 组重新跑过，全部通过。

## v6（2026-11-15）：关掉 hook.js 的 console.log 刷屏

### 04:56 用户发来的日志尾巴
v4 的 3 轮上限这次起了作用：程序打了
`Export failed after 3 rounds, stop retrying` 后干净退出，不再无限
循环——但导出还是失败。连接第 4 次断开，还是在开始渲染后约一分钟，
还是 hera/chlog + river/single 之后（01:12、02:05、03:54、04:56
四次都是这个时间点）。

### 最可能的根因（代码里确认的）
hook.js 每一次画字、改颜色、调方法都要 `console.log` 一次，一页
几千次；每条日志都要走 CDP 发给 pyppeteer，Python 再写到命令行
窗口。日志里约 16 毫秒一行、每秒约 60 行持续不断，约一分钟后
连接就被淹没断开（websockets 的 ping/pong 在这个洪流里得不到及时
响应，连接被判定死亡，正好是 `no close frame received or sent`
这个报错）。hera/chlog + river/single 只是断开被发现前最后处理的
请求，是时间点重合，不是它俩杀死了连接。

### v6 改了什么（只改 `weread_exporter/hook.js`）
8 处 `console.log(...)` 全改成注释（`// v6: ...`），文件头加了
`v6-silenced-logging` 标记。数据收集（`data.markdown` /
`data.complete`）不依赖 console.log，只关日志，不动逻辑。
之后日志里画字那几千行刷屏没了是正常的，说明 v6 生效了。

### v6 测了什么
- 新增 `test_v6_hook.py`（静态检查）：4 组全部通过——代码行里
  没有 `console.log(`，v6 标记在，数据收集逻辑（complete / markdown /
  updateMarkdown / getContext 劫持 / fillText）都在，`node --check`
  语法通过。
- v2 的 `test_fetch_patch.py` 8 组、v3 的 `test_v3_relaunch.py` 4 组、
  v4 的 `test_v4_pageturn.py` 5 组、v5 的 `test_v5_selector.py` 2 组
  重新跑过，全部通过。

### 如果 v6 之后还是断开
那就不是日志洪流，下一条线是 Chrome 本身崩溃（内存 / GPU）：
看任务管理器里 Chrome 内存、或试 `--disable-gpu`。先不改，等 v6
跑完再说。

## 没测到的（必须说清楚）
- 没有在真机 Chrome 157 + 真实微信读书账号上跑完整导出。Mock 测试证明的是
  拦截/注入/回包的逻辑通了，不能证明微信读书 2026-11-15 的页面结构、
  登录流程、章节加载没有其他变化。
- 如果跑起来在新的地方报错，把黑窗口最后 30 行发回来，重点看有没有
  `Fetch.` 开头的报错、`canvasContextHandler`、`load selector timeout`。

## 怎么用（Windows）
1. 先把正在跑的那次停掉（CMD 里 `Ctrl+C`，或直接关掉黑窗口），
   不然跑着的还是旧代码。
2. 先备份（apply 脚本会自动做）：把原来
   `C:\Users\a1571\weread-exporter\weread_exporter\webproxy.py`
   复制一份为 `webproxy.py.bak-network`，把 `webpage.py` 复制一份为
   `webpage.py.bak`，把 `__main__.py` 复制一份为 `__main__.py.bak`。
3. 把本补丁包里的 `weread_exporter\webproxy.py`、
   `weread_exporter\webpage.py` 和 `weread_exporter\__main__.py`
   覆盖到上面那个位置。
   最省事：解压本包后双击 `apply-fetch-patch.bat`，它会做备份+覆盖+
   版本检查+跑 Mock 测试。v6 包的 zip 文件名带 `-v6`，别和之前
   的 v2/v3/v4/v5 包搞混。v6 开始有四个文件，多了 `hook.js`。
4. 在 `(.venv)` 的 CMD 里重新跑（Chrome 还是用你日常的 157，不用降级）：
   ```
   cd %USERPROFILE%\weread-exporter
   .venv\Scripts\activate.bat
   python -m weread_exporter -b 771324e0813abbe5bg0187f1 -o epub -o pdf
   ```
   等日志出现 `Save file ...epub complete` 和 `Save file ...pdf complete`，
   再 `dir output` 确认。

## 回滚
```
cd %USERPROFILE%\weread-exporter\weread_exporter
copy /y webproxy.py.bak-network webproxy.py
copy /y webpage.py.bak webpage.py
copy /y __main__.py.bak __main__.py
```
回滚后就是原来那个版本，在 Chrome 157 上会在第 2 章报
`Network.setRequestInterception wasn't found`，需要配合 Chrome 155 才能用
（见之前给的 `weread-exporter-chrome155-export.bat`）。
