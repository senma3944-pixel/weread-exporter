@echo off
REM weread-exporter Fetch.enable 补丁 v6 - 一键应用 (Windows)
REM 用法: 解压补丁包后, 双击这个 .bat
REM 它会: 备份原文件 -> 覆盖为补丁版 -> 跑 Mock 自测
REM v6 包含四个文件:
REM   weread_exporter\webproxy.py  (v2: Fetch.enable + 超时兜底)
REM   weread_exporter\webpage.py   (v3: launch() 重置 _proxy_installed;
REM                                 v4: 翻页改 JS 点击 + 去空白比较 +
REM                                 单章翻页上限 200;
REM                                 v5: 翻页选择器改成
REM                                 renderTarget_pager_button_right，
REM                                 旧的 readerFooter_button 已失效)
REM   weread_exporter\__main__.py  (v4: 整本导出最多重试 3 轮，
REM                                 还不行就报错退出，不再无限重试)
REM   weread_exporter\hook.js      (v6: 关掉 console.log 刷屏，
REM                                 一页几千次日志曾把连接淹没断开)
setlocal
set PATCH_DIR=%~dp0
set TARGET_DIR=%USERPROFILE%\weread-exporter\weread_exporter

if not exist "%TARGET_DIR%\webproxy.py" (
  echo [失败] 没找到 %TARGET_DIR%\webproxy.py
  echo 请先确认 weread-exporter 装在 %USERPROFILE%\weread-exporter
  pause
  exit /b 1
)
if not exist "%TARGET_DIR%\webpage.py" (
  echo [失败] 没找到 %TARGET_DIR%\webpage.py
  pause
  exit /b 1
)
if not exist "%TARGET_DIR%\__main__.py" (
  echo [失败] 没找到 %TARGET_DIR%\__main__.py
  pause
  exit /b 1
)
if not exist "%TARGET_DIR%\hook.js" (
  echo [失败] 没找到 %TARGET_DIR%\hook.js
  pause
  exit /b 1
)
if not exist "%PATCH_DIR%weread_exporter\webproxy.py" (
  echo [失败] 没找到补丁文件 %PATCH_DIR%weread_exporter\webproxy.py
  pause
  exit /b 1
)
if not exist "%PATCH_DIR%weread_exporter\webpage.py" (
  echo [失败] 没找到补丁文件 %PATCH_DIR%weread_exporter\webpage.py
  pause
  exit /b 1
)
if not exist "%PATCH_DIR%weread_exporter\__main__.py" (
  echo [失败] 没找到补丁文件 %PATCH_DIR%weread_exporter\__main__.py
  pause
  exit /b 1
)
if not exist "%PATCH_DIR%weread_exporter\hook.js" (
  echo [失败] 没找到补丁文件 %PATCH_DIR%weread_exporter\hook.js
  pause
  exit /b 1
)

echo 1) 备份原文件...
copy /y "%TARGET_DIR%\webproxy.py" "%TARGET_DIR%\webproxy.py.bak-network"
copy /y "%TARGET_DIR%\webpage.py" "%TARGET_DIR%\webpage.py.bak"
copy /y "%TARGET_DIR%\__main__.py" "%TARGET_DIR%\__main__.py.bak"
copy /y "%TARGET_DIR%\hook.js" "%TARGET_DIR%\hook.js.bak"
echo    已备份到 webproxy.py.bak-network、webpage.py.bak、__main__.py.bak、hook.js.bak
echo.

echo 2) 覆盖为补丁版...
copy /y "%PATCH_DIR%weread_exporter\webproxy.py" "%TARGET_DIR%\webproxy.py"
copy /y "%PATCH_DIR%weread_exporter\webpage.py" "%TARGET_DIR%\webpage.py"
copy /y "%PATCH_DIR%weread_exporter\__main__.py" "%TARGET_DIR%\__main__.py"
copy /y "%PATCH_DIR%weread_exporter\hook.js" "%TARGET_DIR%\hook.js"
echo.

echo 3) 验证补丁版本...
findstr /c:"FETCH_RESPONSE_TIMEOUT" "%TARGET_DIR%\webproxy.py" >nul
if errorlevel 1 (
  echo [失败] webproxy.py 不是 v2/v3/v4 版
  pause
  exit /b 1
)
findstr /c:"_proxy_installed = False" "%TARGET_DIR%\webpage.py" >nul
if errorlevel 1 (
  echo [失败] webpage.py 不是 v3/v4/v5 版
  pause
  exit /b 1
)
findstr /c:"renderTarget_pager_button_right" "%TARGET_DIR%\webpage.py" >nul
if errorlevel 1 (
  echo [失败] webpage.py 不是 v5 版
  pause
  exit /b 1
)
findstr /c:"MAX_EXPORT_ROUNDS" "%TARGET_DIR%\__main__.py" >nul
if errorlevel 1 (
  echo [失败] __main__.py 不是 v4/v5/v6 版
  pause
  exit /b 1
)
findstr /c:"v6-silenced-logging" "%TARGET_DIR%\hook.js" >nul
if errorlevel 1 (
  echo [失败] hook.js 不是 v6 版
  pause
  exit /b 1
)
echo    webproxy.py 是 v2 版, webpage.py 是 v5 版, __main__.py 是 v4 版, hook.js 是 v6 版
echo.

echo 4) 跑 Mock 自测 (不需要真 Chrome)...
cd /d "%USERPROFILE%\weread-exporter"
call .venv\Scripts\activate.bat 2>nul
if exist "%PATCH_DIR%test_fetch_patch.py" (
  python "%PATCH_DIR%test_fetch_patch.py"
  if errorlevel 1 goto :rollback
)
if exist "%PATCH_DIR%test_v3_relaunch.py" (
  python "%PATCH_DIR%test_v3_relaunch.py"
  if errorlevel 1 goto :rollback
)
if exist "%PATCH_DIR%test_v4_pageturn.py" (
  python "%PATCH_DIR%test_v4_pageturn.py"
  if errorlevel 1 goto :rollback
)
if exist "%PATCH_DIR%test_v5_selector.py" (
  python "%PATCH_DIR%test_v5_selector.py"
  if errorlevel 1 goto :rollback
)
if exist "%PATCH_DIR%test_v6_hook.py" (
  python "%PATCH_DIR%test_v6_hook.py"
  if errorlevel 1 goto :rollback
)
echo.
echo 补丁已应用! 接下来在 (.venv) 的 CMD 里跑:
echo   cd %USERPROFILE%\weread-exporter
echo   .venv\Scripts\activate.bat
echo   set PATH=%%PATH%%;C:\Program Files\Google\Chrome\Application
echo   python -m weread_exporter -b 771324e0813abbe5bg0187f1 -o epub -o pdf
echo.
echo 回滚方法:
echo   copy /y "%TARGET_DIR%\webproxy.py.bak-network" "%TARGET_DIR%\webproxy.py"
echo   copy /y "%TARGET_DIR%\webpage.py.bak" "%TARGET_DIR%\webpage.py"
echo   copy /y "%TARGET_DIR%\__main__.py.bak" "%TARGET_DIR%\__main__.py"
echo   copy /y "%TARGET_DIR%\hook.js.bak" "%TARGET_DIR%\hook.js"
pause
exit /b 0

:rollback
echo.
echo [注意] 自测没通过, 正在回滚...
copy /y "%TARGET_DIR%\webproxy.py.bak-network" "%TARGET_DIR%\webproxy.py"
copy /y "%TARGET_DIR%\webpage.py.bak" "%TARGET_DIR%\webpage.py"
copy /y "%TARGET_DIR%\__main__.py.bak" "%TARGET_DIR%\__main__.py"
copy /y "%TARGET_DIR%\hook.js.bak" "%TARGET_DIR%\hook.js"
pause
exit /b 1
