"""v3 自测：断连重试后，新的浏览器必须重新启用 Fetch 拦截。

背景（用户 2026-11-15 02:05 的日志）：
- 第一轮 Chrome 的 websocket 在 02:05:50 断掉，__main__ 的重试循环
  close() 再 launch() 同一个 WeReadWebPage 对象，重跑第 2 章。
- 但 webpage.py 的 pre_load_page() 开头有
      if self._proxy_installed: return
  而 _proxy_installed 只在 __init__ 里设 False，launch()/close() 都
  不重置。于是第二轮里 pre_load_page 直接 return，新会话永远收不到
  Fetch.enable，日志里第二轮没有任何 "Setup interception" /
  "Handle request"，hook 注不进去，get_markdown 必报
  canvasContextHandler is not defined。
- v3 修复：在 launch() 开头加 self._proxy_installed = False。

测法（不需要真 Chrome / 不需要登录）：
1. _proxy_installed=True 时 pre_load_page() 不调 setup（同一会话内
   只装一次，这个保护还在）；
2. 模拟 launch() 的重置（_proxy_installed=False）后，pre_load_page()
   重新调 setup_interception（第二轮新会话能拦截）；
3. 再模拟一次断连+重 launch，setup 一共被调 2 次；
4. 静态检查：launch() 的源码里确实含有重置那一行，且在
   pyppeteer.launch 调用之前。

跑法：python test_v3_relaunch.py
"""
import asyncio
import importlib.util
import inspect
import os
import sys
import types

HERE = os.path.dirname(os.path.abspath(__file__))
PKG_DIR = os.path.join(HERE, "weread_exporter")

# ---- stub pyppeteer：webpage/webproxy 只在 import 时用到它 ----
_pyppeteer = types.ModuleType("pyppeteer")
_pyppeteer_page = types.ModuleType("pyppeteer.page")
_pyppeteer_page.Page = object
_pyppeteer_browser = types.ModuleType("pyppeteer.browser")
_pyppeteer_browser.Browser = object
_pyppeteer_errors = types.ModuleType("pyppeteer.errors")


class _TimeoutError(Exception):
    pass


class _NetworkError(Exception):
    pass


class _ElementHandleError(Exception):
    pass


_pyppeteer_errors.TimeoutError = _TimeoutError
_pyppeteer_errors.NetworkError = _NetworkError
_pyppeteer_errors.ElementHandleError = _ElementHandleError
_pyppeteer.page = _pyppeteer_page
_pyppeteer.browser = _pyppeteer_browser
_pyppeteer.errors = _pyppeteer_errors
sys.modules["pyppeteer"] = _pyppeteer
sys.modules["pyppeteer.page"] = _pyppeteer_page
sys.modules["pyppeteer.browser"] = _pyppeteer_browser
sys.modules["pyppeteer.errors"] = _pyppeteer_errors

# ---- stub aiohttp：webproxy.get_http_response 直接用它 ----
_aiohttp = types.ModuleType("aiohttp")


class _ClientTimeout:
    def __init__(self, total=None):
        self.total = total


class _ClientSession:
    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False


_aiohttp.ClientTimeout = _ClientTimeout
_aiohttp.ClientSession = _ClientSession
sys.modules["aiohttp"] = _aiohttp

# ---- stub weread_exporter.utils ----
fake_utils = types.ModuleType("weread_exporter.utils")


class _ChromeNotInstalledError(Exception):
    pass


class _BreakExportingError(Exception):
    pass


class _InvalidUserError(Exception):
    pass


class _LoadChapterFailedError(Exception):
    pass


class _LoginRequiredError(Exception):
    pass


async def _fake_fetch(url, method="GET", headers=None, data=None,
                      respond_with_headers=False):
    return b"<html></html>"


fake_utils.fetch = _fake_fetch
fake_utils.ChromeNotInstalledError = _ChromeNotInstalledError
fake_utils.BreakExportingError = _BreakExportingError
fake_utils.InvalidUserError = _InvalidUserError
fake_utils.LoadChapterFailedError = _LoadChapterFailedError
fake_utils.LoginRequiredError = _LoginRequiredError
sys.modules["weread_exporter.utils"] = fake_utils

# ---- 把 weread_exporter 当作包加载（为了 from . import ...） ----
pkg = types.ModuleType("weread_exporter")
pkg.__path__ = [PKG_DIR]
sys.modules["weread_exporter"] = pkg


def _load(name, filename):
    spec = importlib.util.spec_from_file_location(
        "weread_exporter." + name, os.path.join(PKG_DIR, filename)
    )
    mod = importlib.util.module_from_spec(spec)
    sys.modules["weread_exporter." + name] = mod
    spec.loader.exec_module(mod)
    return mod


webproxy = _load("webproxy", "webproxy.py")
webpage = _load("webpage", "webpage.py")


class RecordingProxy:
    """替代 webproxy.WebProxy，只记录 setup_interception 被调了几次。"""

    calls = []

    def __init__(self, page, rules):
        self.page = page
        self.rules = rules

    async def setup_interception(self):
        RecordingProxy.calls.append(1)


async def main():
    # 换上记录用的假 Proxy
    real_proxy_cls = webproxy.WebProxy
    webproxy.WebProxy = RecordingProxy
    try:
        # 构造一个 WeReadWebPage，不走 __init__（不碰 cookie 文件）
        obj = webpage.WeReadWebPage.__new__(webpage.WeReadWebPage)
        obj._proxy_installed = True  # 模拟：第一轮已经装过拦截
        obj._hook_script_name = "1.abcdef01.js"
        obj._book_id = "771324e0813abbe5bg0187f1"
        obj._page = object()

        # 1. 同一会话内再次 pre_load_page：不重复安装
        await obj.pre_load_page()
        assert len(RecordingProxy.calls) == 0, RecordingProxy.calls
        print("1. _proxy_installed=True 时 pre_load_page 不重复安装 OK")

        # 2. 模拟 v3 的 launch() 重置：断连重 launch 后必须重新安装
        obj._proxy_installed = False  # == launch() 开头那行做的事
        await obj.pre_load_page()
        assert len(RecordingProxy.calls) == 1, RecordingProxy.calls
        assert obj._proxy_installed is True
        print("2. 重置标志后 pre_load_page 重新调 setup_interception OK")

        # 3. 再模拟一次断连 + 重 launch：累计调 2 次
        obj._proxy_installed = False
        await obj.pre_load_page()
        assert len(RecordingProxy.calls) == 2, RecordingProxy.calls
        print("3. 第二次断连重 launch 后 setup 累计 2 次 OK")

        # 4. 静态检查：修复确实写在 launch() 里，且在真正启动 Chrome 之前
        src = inspect.getsource(webpage.WeReadWebPage.launch)
        assert "self._proxy_installed = False" in src, "launch() 里没有重置行"
        assert src.index("self._proxy_installed = False") < src.index(
            "pyppeteer.launch"
        ), "重置行必须在 pyppeteer.launch 之前"
        print("4. launch() 源码含重置行、且在 pyppeteer.launch 之前 OK")
    finally:
        webproxy.WebProxy = real_proxy_cls

    print("\nALL V3 TESTS PASSED")


if __name__ == "__main__":
    asyncio.run(main())
