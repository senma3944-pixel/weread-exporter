"""v6 自测：hook.js 的 console.log 刷屏已关掉，数据收集逻辑还在。

背景（用户 2026-11-15 04:56 的日志）：
第 4 次 `connection unexpectedly closed`，还是在开始渲染后约一分钟，
还是 hera/chlog + river/single 之后。v4 的 3 轮上限这次起了作用：
程序打了 `Export failed after 3 rounds, stop retrying` 后干净退出，
不再无限循环——但导出还是失败，连接断开成了最后的拦路虎。

最可能的根因（代码里确认的）：hook.js 每一次画字、改颜色、调方法
都要 console.log 一次，一页几千次；每条日志都要走 CDP 发给
pyppeteer，Python 再写到命令行窗口。日志里约 16 毫秒一行、每秒
约 60 行，持续不断，约一分钟后连接就被淹没断开（websockets 的
ping/pong 在这个洪流里得不到及时响应，连接被判定死亡，正好是
`no close frame received or sent` 这个报错）。

v6 改了什么（只改 `weread_exporter/hook.js`）：
8 处 `console.log(...)` 全改成注释（`// v6: ...`），数据收集
（data.markdown / data.complete）不依赖 console.log，只关日志，
不动逻辑。文件头加了 `v6-silenced-logging` 标记。

测法（静态检查，不需要真 Chrome）：
1. hook.js 的代码行（不算注释）里没有 `console.log(`；
2. v6 标记在；
3. 数据收集的关键逻辑还在：complete 标记、markdown 累积、
   updateMarkdown、getContext 劫持、fillText 处理；
4. 有 node 的话再跑 `node --check` 做一次语法检查。

跑法：python test_v6_hook.py
"""
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
HOOK = os.path.join(HERE, "weread_exporter", "hook.js")


def main():
    with open(HOOK, encoding="utf-8") as fp:
        lines = fp.read().splitlines()
    code_lines = [
        line for line in lines if not line.strip().startswith("//")
    ]
    code = "\n".join(code_lines)

    # 1. 代码行里没有 console.log
    assert "console.log(" not in code, "代码里还有 console.log"
    print("1. 代码行里没有 console.log OK")

    # 2. v6 标记在
    assert "v6-silenced-logging" in "\n".join(lines)
    print("2. v6 标记在 OK")

    # 3. 数据收集逻辑还在
    for needle in (
        "data.complete = true",
        "data.markdown +=",
        "updateMarkdown",
        "getContext",
        "fillText",
        "clearCanvasCache",
        "canvasContextHandler",
    ):
        assert needle in code, needle
    print("3. 数据收集逻辑（complete/markdown/updateMarkdown/劫持）都在 OK")

    # 4. 有 node 就做一次语法检查
    node = shutil.which("node")
    if node:
        r = subprocess.run(
            [node, "--check", HOOK],
            capture_output=True, text=True, timeout=30,
        )
        assert r.returncode == 0, r.stderr
        print("4. node --check 语法通过 OK")
    else:
        print("4. 本机没有 node，跳过语法检查（改动只是注释掉整行语句）")

    print("\nALL V6 TESTS PASSED")


if __name__ == "__main__":
    sys.exit(main())
